                                                                     
                                                                     
         








/* 


Q_1.   Determine the mean, RMS, number of counts, and error on the mean for the five prominent peaks in the Na-22, Co-60, and Cs-137 spectra. Quote the gamma-ray energy and uncertainty for each of the peaks; include a citation of your reference source.



*/ 




/* -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



                            Part A.   Isotope  Na-22



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

*/ 








//  Opening and Creating histogram of Isotope Na-22






#include <iostream> 
#include <fstream>
#include <TFile.h>
#include <TH1F.h>
#include <string>
#include <TGraphErrors.h>
#include <TF1.h>
#include <TRandom.h>
#include <TCanvas.h>
#include <TString.h>
#include <vector>
#include <string>
using namespace std; 




void Read_xy_file(TString filename, TString histname){

  Int_t bin, data;
  ifstream infile;
  
  Int_t minimum=kMaxInt;
  Int_t maximum=kMinInt;

  infile.open(filename);
  if (! infile.good()){
    cerr << "Couldn't open file " << filename << "." << endl;
    infile.close();
    return;
  }

  while(!infile.eof()){
      infile >> bin >> data;
      if(bin>maximum)
	maximum=bin;
      if(bin<minimum)
	minimum=bin;
    }
    //  infile.close();
    
  cout << "after first loop"<< endl;

  if(minimum>maximum){
    cerr << "Minimum is greater than Maximum" << minimum << maximum
	 << endl;
    return;
  }
  cout << "after test on minimum>maximum"<< endl;


  TH1F *myhist = new TH1F(histname,histname,maximum-minimum+1, minimum-.5, maximum+.5);

  cout << "after making the hist"<< endl;

  infile.clear();
  infile.seekg(0, ios::beg);


  //  infile.open(filename);
  while (!infile.eof()) {
    infile >> bin >> data;
    if (bin%100==0)
      cout << "\t" << bin
	   << "\t" << data << endl;
    for (size_t i=0; i<data; i++){
      myhist->Fill(bin);
    }
  }
  
  
  
  


  infile.close();
  
  
// Creating a TCanvas to draw the histogram
TCanvas *c1 = new TCanvas("c1", "Na_22 spectrum", 800, 600);

// Drawing the histogram on the canvas
myhist->Draw();
    
// Zoom in on the x-axis
myhist->GetXaxis()->SetRangeUser(0, 6000);  


 // Perform a Gaussian fit
    TF1 *gausFit = new TF1("gausFit", "gaus", minimum, maximum);
    myhist->Fit(gausFit, "R");  // "R" means fit in the specified range

    // Draw the fit
    gausFit->SetLineColor(kRed);
    gausFit->Draw("SAME");

//Save the canvas to a file
c1->SaveAs(histname + ".pdf");






    
   
  
};



void Run1 () {


Read_xy_file("germaniumdet_na22.xy", "na_22_histo");

}































